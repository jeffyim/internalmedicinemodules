<div id="page-one">
	<p class="title">Re-cap</p>
	<ol>

		<li>Main issue keeping the patient in the hospital.</li>
		<li>Other important issues that needs investigation or active management.</li>
		<li>Writing down investigations and management for each issues (if applicable).</li>
		<li>Best Practices (if the patient is being admitted):
			<ul>
				<li>These involve (but not limited to) documenting plans for:
					<ul>
						<li>IV fluids (at what rate and how long?)</li>
						<li>Lines (IV access, foley, feeding tubes)</li>
						<li>Pain/anti-emetic medications (doses, frequency)</li>
						<li>Code status</li>
						<li>DVT prophylaxis</li>
					</ul>
				</li>
			</ul>
		<li>Disposition plan (Home care, assisted living, hospice, follow-up?).</li>
	</ol>
	<a class="next-section-link" href="index.php?section=problem-list&subsection=case-four">next section</a>
</div>
