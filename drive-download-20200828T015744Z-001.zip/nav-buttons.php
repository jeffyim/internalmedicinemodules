
<button id="prev-button"> prev page </button>
<button id="next-button"> next page </button>
<button id="answer-button"> show answer </button>